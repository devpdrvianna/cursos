#!/bin/bash

default_jpg='/';
default_mp3='/';
default_resolution='1920:1080';
default_filename="/";

OUTPUT=$(yad \
  --title="JPG and MP3 to MP4" \
  --form \
    --text="Options" \
    --separator="," \
    --field="JPG:FL" \
    --field="MP3:FL" \
    --field="Resolution" \
    --field="MP4 (Output):SFL" \
    --button="Create MP4":1 \
    "$default_jpg" \
    "$default_mp3" \
    "$default_resolution" \
    "$default_filename" \
  ) accepted=$?

if ((accepted == 1)); then
  jpgfile=$(   awk -F, '{print $1}' <<<$OUTPUT)
  mp3file=$(   awk -F, '{print $2}' <<<$OUTPUT)
  resolution=$(awk -F, '{print $3}' <<<$OUTPUT)
  filename=$(  awk -F, '{print $4}' <<<$OUTPUT)

  echo $jpgfile $mp3file $resolution $filename
fi
