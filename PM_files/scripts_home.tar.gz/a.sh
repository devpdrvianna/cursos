#!/bin/bash

var="a b c d"

for i in $var
 do
	 #echo ${i}teste
	 echo $i
	 echo ${i[@]}
 done
