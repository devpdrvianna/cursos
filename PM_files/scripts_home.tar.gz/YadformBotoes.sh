#!/usr/bin/env bash

yad --form --center --borders=10 --window-icon="./icon.ico" --back=cyan --title="Central de Software" --columns=3 --no-buttons --image-on-top \
--image=./itau.png \
--field="  Top!htop":btn "free -h" \
--field="  picom.conf!text-editor":fbtn "leafpad $HOME/.config/picom.conf" \
--field="  Calendar!calendar":dt "yad --calendar --no-buttons --width=400 --center --undecorated --close-on-unfocus" \
--field="  Autostart!text-editor":fbtn "leafpad $HOME/.config/openbox/autostart" \
--field="  System Upgrade!terminal":fbtn "ls -la" \
--field="  rc.xml!text-editor":fbtn "leafpad $HOME/.config/openbox/rc.xml" \
______________________________________

#Here is the code for the script that the "System Upgrade" button is calling for...

##!/usr/bin/env bash
#pkexec env DISPLAY=$DISPLAY XAUTHORITY=$XAUTHORITY xterm -e "apt-get update&&apt-get dist-upgrade"
