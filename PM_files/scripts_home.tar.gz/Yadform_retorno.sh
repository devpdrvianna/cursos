sudo yum install code | yad --list --title "Search Results" --text "Finding all header files.." --column "Files"
