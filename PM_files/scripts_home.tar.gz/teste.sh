#!/bin/bash
echo Iniciando....
tcpdump
echo Fim!
