find . -name '*.h' | yad --list --title "Search Results" --text "Finding all header files.." --column "Files"
