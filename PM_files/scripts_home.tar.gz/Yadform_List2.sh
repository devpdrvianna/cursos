yad --list --tree --column "Items" f Fruits 1:f Apple 2:f Lemon 3:f banana v Vegetables 3:v Popato 4:v Onion
