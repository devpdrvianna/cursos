#!/bin/bash

function one () {
var1="${1}${2}${3}ONE"
echo $var1
}
export -f one

function two () {
var2="${1}${2}${3}TWO"
echo $var2
}
export -f two

yad --form --field="first name" "" --field="surname" "" --field="gender" "" --field="one:BTN" 'bash -c "one %1 %2 %3"' --field="two:BTN" 'bash -c "two %1 %2 %3"'

