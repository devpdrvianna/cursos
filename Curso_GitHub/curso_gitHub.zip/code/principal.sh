#!/bin/bash
var=2000
result=$(expr 1 + $var)
echo $result