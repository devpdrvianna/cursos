
![Logo fo git](https://sujeitoprogramador.com/wp-content/uploads/2021/04/gitimage.png)

[Bemvindo](#bem-vindo-ao-curso) |
[Modulos](#modulos) |
[Titulos](#titulos) |
[Negrito-Italico](##enfase-de-texto-negrito-e-italico)


# Bem vindo ao curso 
Nesse grupo vc vai aprender a dominar


## Modulos:

Entendendo Branches

# Titulos
# Titulo <h1>
## Titulo <h2>
### Titulo <h3>
#### Titulo <h4>
##### Titulo <h5>
###### Titulo <h6>


## Enfase de texto negrito e italico
**git**  - negrito

_git em italico_ 

_Texto **misturando** italico e negrito_

# Imagem e links


# Rede social
[**Instagran**](https://instagram.com/sujeitoprogramador)

[**Youtube**](https://youtube.com/sujeitoprogramador)





## Listas nao ordenada
* Comecando com git
* Aprendendo sobre branchs
* Git Avancado
* usando git profisional

## lista ordenada
1. Comecando com git
        
        1. o que e git
        2. treinamento 
2. Aprendendo sobre branchs
3. Git Avancado
        
        1. teste
4. usando git profisional

#Block code
>Este e um block code para destacar o texto
>Segunta area destacada
>
>Pulando uma linha no blockcode

## Exemplo de codigo

**Comando para rodar o projeto**
```
mpm start
```
**Outro Exemplo**
```js
Function shownname(name){
    return 'Bem vindo'

}
```

**Uso Html**
```html
<h1>
    Titulo do projeto
</h1>
```
## Task List

**Ultimos update:**
- [x] Login com facebook
- [ ] Site responsivo
- [ ] pagina sobre 

## Tabelas

Propriedades | Descrição
-----------  | --------
Name | Informar o nome do user
Size | Para definir o tamanho
background | Cor de fundo
onpress | Funcao clicar no botao





